import React, { useState, useEffect } from 'react';
import { Image, ImageBackground, ScrollView, Text, TextInput, TouchableOpacity, View, StatusBar, SafeAreaView, Button } from 'react-native';
import { styles } from './styles';
import FastImage from 'react-native-fast-image';
import Modal from "react-native-modal";
import AsyncStorage from "@react-native-community/async-storage";
// import admob, { MaxAdContentRating } from '@react-native-firebase/admob';
import { AppOpenAd, InterstitialAd, RewardedAd, BannerAdSize, BannerAd, TestIds } from 'react-native-google-mobile-ads';

export default function Otp({ navigation }) {
    const [isModalVisible, setIsModalVisible] = useState(false)
    const [refmodel, setRefmodel] = useState('0')
    const [loding, setLoading] = useState(false)
    const [tempdata, settempdata] = useState('')
    useEffect(() => {
        navigation.addListener('focus', async () => {
            const modalopen = await AsyncStorage.getItem('akrefre')
            const firstmodal = JSON.parse(modalopen)
            console.log('firstmodel===>> ', firstmodal)
            const result = await AsyncStorage.getItem('logindata')
            const screenData = JSON.parse(result)
            global.uername = screenData.name
            global.uerid = screenData.id
            global.templename = screenData.temple_name
            getkulamdis(screenData.kulam)
            requeststatus()
            getuserProfile();
            gettempledetail()

        })
    }, [])
    const getkulamdis = (kulam) => {

        fetch(global.url + 'getkulam', {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                'Content-type': 'application/json',
            }
        }).then((res) => res.json(kulam))
            .then((json) => {
                console.log('========= getkulam ', kulam)
                for (var i = 0; i < json.data.length; i++) {
                    if (kulam == json.data[i].id) {
                        console.log(json.data[i].name)
                        global.kulam = json.data[i].name
                    }
                }

            })

    }

    const gettempledetail = async () => {
        const result = await AsyncStorage.getItem('logindata')
        const screenData = JSON.parse(result)
        setLoading(true)
        fetch(global.url + 'gettempledetail', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: 7,
            })
        })
            .then((res) => res.json())
            .then(async (json) => {
                console.log('gettempledetail data ===>>', json)
                if (json.success == true) {
                    settempdata(json.data)
                } else {

                }
                setLoading(false)
            })
    }
    const getuserProfile = async () => {
        const result = await AsyncStorage.getItem('logindata')
        const screenData = JSON.parse(result)
        fetch(global.url + 'getuserprofile', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                // console.log('daata all =>', json.data[0].is_verified)
                // setRefmodel(json.data[0].is_verified)
            })
            .catch((err) => console.log(err))
    }
    const requeststatus = async () => {
        const result = await AsyncStorage.getItem('logindata')
        const screenData = JSON.parse(result)
        fetch(global.url + 'requeststatus', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.message !== "No askedreference found.") {
                    console.log('requeststatusrequeststatus  =>', json.data[0])
                    setRefmodel(json.data[0].status)
                } else {
                    console.log('--------------')
                    setRefmodel('3')
                }
            })
            .catch((err) => console.log(err))
    }
    const askref = async () => {
        setIsModalVisible(false);
        await AsyncStorage.setItem('akrefre', '1');
        navigation.navigate('Refrence')
    };

    const evento = () => {
        if (refmodel == '1') {
            navigation.navigate('Events')
        } else {
            setIsModalVisible(true)
        }
    }
    const manegh = () => {
        if (refmodel == '1') {
            navigation.navigate('ManageHistory')
        } else {
            setIsModalVisible(true)
        }
    }
    const oldevent = () => {

        if (refmodel == '1') {
            navigation.navigate('Oldevent')
        } else {
            setIsModalVisible(true)
        }
    }
    const callpag = () => {
        if (refmodel == '1') {
            navigation.navigate('Call')
        } else {
            setIsModalVisible(true)
        }
    }

    const gallery = () => {
        if (refmodel == '1') {
            navigation.navigate('ManageGallery1')
        } else {
            setIsModalVisible(true)
        }
    }
    const Callone = () => {
        if (refmodel == '1') {
            navigation.navigate('Callone')
        } else {
            setIsModalVisible(true)
        }

    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: '#ffffff' }}>
            <StatusBar animated={true} backgroundColor="#ffffff" />
            <ScrollView>
                <View style={{ margin: 20 }}>
                    <View style={{ height: 30 }}></View>
                    <View style={{ flexDirection: 'row', width: '100%' }}>
                        <TouchableOpacity style={{ width: '20%' }}>
                            <FastImage style={styles.icon} source={require('../../../assets/images/bell.png')} />
                        </TouchableOpacity>
                        <View style={{ width: '60%' }}>
                            <Text style={styles.name}>Gounder Kudumbam</Text>
                        </View>
                        <View style={{ width: '20%' }}>
                            {/* <FastImage style={styles.iconper} source={require('../../../assets/images/per.png')} /> */}
                        </View>
                    </View>
                    <View style={{ height: 20 }}></View>
                    <View style={{ flexDirection: 'row', width: '100%' }}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.title}>
                                WELCOME {global.uername},
                            </Text>
                        </View>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.id}>
                                ID: {global.uerid}
                            </Text>
                        </View>
                    </View>


                    {tempdata ?
                        <View>
                            {tempdata.map((t, index) => (
                                <TouchableOpacity style={{ width: 350, height: 400, alignSelf: 'center' }}>
                                    <View>
                                        <Text style={{ fontFamily: 'Montserrat-Bold', fontSize: 11, color: '#8D92A3' }}>Kulam: {global.kulam}</Text>
                                        <Text style={{ fontFamily: 'Montserrat-Bold', fontSize: 11, color: '#8D92A3' }}>Temple: {global.templename}</Text>
                                    </View>
                                    <View style={{ height: 20 }}></View>
                                    {t.image ?
                                        <FastImage resizeMode='stretch' style={{ flex: 1, borderRadius: 20 }} source={{ uri: 'https://www.demo603.amrithaa.com/gouku/admin/public/images/' + t.image }} />
                                        :
                                        <FastImage resizeMode='stretch' style={{ flex: 1, borderRadius: 20 }} source={require('../../../assets/images/maa.jpg')} />

                                    }
                                    <Text style={styles.alltxt1}>
                                        {t.name}
                                    </Text>
                                    <Text style={styles.alltxt}>
                                        Updated {t.updated_at}
                                    </Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                        :
                        <TouchableOpacity style={{ width: 350, height: 400, alignSelf: 'center' }} onPress={() => mainimg()}>
                            <FastImage resizeMode='stretch' style={{ flex: 1, borderRadius: 20 }} source={require('../../../assets/images/maa.jpg')} />
                            <Text style={styles.alltxt1}>
                                Shri Ponkaliaman
                            </Text>
                            <Text style={styles.alltxt}>
                                Shivgiri , Endor
                            </Text>
                        </TouchableOpacity>
                    }



                    <View style={{ height: 20 }}></View>

                    <View style={{ flexDirection: 'row', width: '100%' }}>
                        <TouchableOpacity style={{ width: '34%' }} onPress={() => evento()}>
                            <View style={styles.boxview}>
                                <Text style={styles.fntone}>புதிய</Text>
                                <Text style={styles.fnttwo}>நிகழ்வுகள்</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ width: '34%' }} onPress={() => manegh()}>
                            <View style={styles.boxview}>
                                <Text style={styles.fntone}>கோவில்</Text>
                                <Text style={styles.fnttwo}>வரலாறு</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ width: '34%' }} onPress={() => oldevent()}>
                            <View style={styles.boxview}>
                                <Text style={styles.fntone}>பழைய</Text>
                                <Text style={styles.fnttwo}>நிகழ்வுகள்</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ height: 20 }}></View>
                    <View style={{ flexDirection: 'row', width: '100%' }}>
                        <TouchableOpacity style={{ width: '34%' }} onPress={() => Callone()}>
                            <View style={styles.boxview}>
                                <Text style={styles.fntone}>கோவில்</Text>
                                <Text style={styles.fnttwo}>நிர்வாகம்</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ width: '34%' }} onPress={() => gallery()}>
                            <View style={styles.boxview}>
                                <Text style={styles.fntone}>பிற</Text>
                                <Text style={styles.fnttwo}>கோவில்கள்</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ width: '34%' }} onPress={() => callpag()}>
                            <View style={styles.boxview}>
                                <Text style={styles.fntone}>அருமை</Text>
                                <Text style={styles.fnttwo}>பெரியவர்கள்</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ height: 20 }}></View>
                    {refmodel == '1' ?
                        <View style={{ flexDirection: 'row', width: '100%' }}>
                            <TouchableOpacity style={{ width: '34%' }} onPress={() => gallery()}>
                                <View style={styles.boxview}>
                                    <Text style={styles.fntone}>பட</Text>
                                    <Text style={styles.fnttwo}>தொகுப்பு</Text>
                                </View>
                            </TouchableOpacity>
                        </View>

                        : null}
                    <View style={{ height: 20 }}></View>

                    {tempdata ?
                        <View>
                            {tempdata.map((t, index) => (
                                <Text key={index} style={{ color: '#22242A', fontSize: 12, fontFamily: 'Montserrat-Regular' }}>
                                    {t.history}
                                </Text>
                            ))}
                        </View>
                        :
                        <View>
                            <Text style={{ color: '#22242A', fontSize: 12, fontFamily: 'Montserrat-Regular' }}>Our Grandpa Kula deivam.. Its unique and old temple also The temple folloeing old cultures still same way..Yearly once Celebrating Functions its will be seen Unity of people from diffrent Cities at one place..</Text>
                        </View>}
                    <View style={{ height: 10 }}></View>
                    <View style={{ width: '100%', alignItems: 'center' }}>
                        <BannerAd size={BannerAdSize.BANNER}
                            unitId={TestIds.BANNER}
                            requestOptions={
                                {
                                    requestNonPersonalizedAdsOnly: true
                                }
                            } />
                    </View>
                    <View style={{ height: 10 }}></View>
                    {refmodel == '2' || refmodel == '3' ?
                        <TouchableOpacity style={styles.ask} onPress={() => navigation.navigate('Refrence')}>
                            <Text style={{ color: 'white', fontSize: 11, alignSelf: 'center', fontFamily: 'Montserrat-Bold', }}>Ask Refrence</Text>
                        </TouchableOpacity>
                        : null}

                </View>
                <Modal isVisible={isModalVisible} onBackdropPress={() => setIsModalVisible(false)}>
                    {refmodel == '0' ?
                        <View style={{ backgroundColor: 'white', height: 100, borderRadius: 15, justifyContent: 'space-evenly', alignItems: 'center', flexDirection: 'column' }}>
                            <Text style={{ fontFamily: 'Montserrat-Bold', fontSize: 14, color: '#22242A' }}>Request allready send</Text>
                        </View>
                        : null}
                    {refmodel == '2' ?
                        <View style={{ backgroundColor: 'white', height: 100, borderRadius: 15, justifyContent: 'space-evenly', alignItems: 'center', flexDirection: 'column' }}>
                            <Text style={{ fontFamily: 'Montserrat-Bold', fontSize: 14, color: '#22242A' }}>Request allready send, but your Request is rejected.</Text>
                        </View>
                        : null}
                    {refmodel == '3' ?
                        <View style={{ backgroundColor: 'white', height: 300, borderRadius: 15, justifyContent: 'space-evenly', alignItems: 'center', flexDirection: 'column' }}>
                            <Text style={{ fontFamily: 'Montserrat-Bold', fontSize: 14, color: '#22242A' }}>Hi, Sorry</Text>
                            <Text style={{ fontFamily: 'Montserrat-Regular', fontSize: 12, color: '#8D92A3' }}>To view this section you should be a verified user</Text>
                            <FastImage style={{ height: 100, width: 100 }} source={require('../../../assets/images/cross.png')} />
                            <TouchableOpacity onPress={() => askref()} style={{ width: 100, backgroundColor: '#7B221E', height: 25, justifyContent: 'center', alignItems: 'center', borderRadius: 50 }}>
                                <Text style={{ color: 'white', fontFamily: 'Montserrat-Bold', fontSize: 11 }}>Ask Refrence</Text>
                            </TouchableOpacity>
                        </View>
                        : null}
                </Modal>
            </ScrollView>
        </SafeAreaView>
    )
}
//work like this is ok?